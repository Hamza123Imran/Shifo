import React from "react";
import Providers from "./app/navigation/stack";

const App = () => {
  return <Providers />;
};

export default App;
