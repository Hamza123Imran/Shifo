import * as React from "react";
import { View, Text, StyleSheet, SafeAreaView } from "react-native";

class Screen extends React.Component {
  render() {
    return <View style={styles.container}></View>;
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    flex: 1,
  },
});

export default Screen;
