import React, { Component } from "react";
import { Text, StyleSheet, View, TouchableOpacity, Image } from "react-native";
import theme from "../styles/theme";
import Header from "../components/Header";

export default class GiftCard extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          mainTitle="bidali"
          subTitle="Default Wallet"
          openDrawer={() => this.props.navigation.openDrawer()}
          icon="md-menu"
        />
        <View style={styles.innerContainer}>
          <Image
            source={require("../../assets/icons/giftcards.png")}
            style={{ width: 15, height: 25 }}
          />
          <Text style={{ fontSize: 24 }}>BIDALI</Text>
          <View style={styles.btn}>
            <TouchableOpacity>
              <Text style={{ color: "white" }}>SELECT GIFT CARD</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  innerContainer: {
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "row",
    flex: 1,
  },
  btn: {
    alignSelf: "center",
    justifyContent: "center",
    backgroundColor: theme.mainColor,
    padding: 10,
    bottom: 10,
    position: "absolute",
    width: "90%",
    alignItems: "center",
  },
});
