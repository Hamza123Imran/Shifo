import React, { Component } from "react";
import { Text, StyleSheet, View, Button } from "react-native";
import Header from "../components/Header";

export default class FIO extends Component {
  render() {
    return (
      <View style={{ flex: 1 }}>
        <Header
          mainTitle="FIO"
          subTitle="Default Wallet"
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <Text style={{ padding: 10 }}>
          You have to create a FIO Wallet first.
        </Text>
        <View
          style={{ flex: 1, alignSelf: "center", justifyContent: "center" }}
        >
          <Button title="Create FIO Account" />
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({});
