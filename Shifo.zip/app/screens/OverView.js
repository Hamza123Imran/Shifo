import * as React from "react";
import { View, Text, StyleSheet } from "react-native";
import UsdVsBtc from "../../src/components/UsdVsBtc";
import FloatingButton from "../../src/components/FloatingButton";
import Header from "../../src/components/Header";

class OverView extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          mainTitle="Overview"
          subTitle=" Default Wallet"
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <View style={styles.section}>
          <Text style={styles.ttext}>0.00</Text>
          <Text style={styles.tcurrency}>USD</Text>
        </View>
        <UsdVsBtc />
        <FloatingButton
          AddCoins={() => this.props.navigation.navigate("AddCoins")}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    flex: 1,
  },
  section: {
    marginTop: "15%",
    alignSelf: "center",
    marginBottom: "10%",
  },
  ttext: {
    fontSize: 42,
    color: "grey",
  },
  tcurrency: {
    marginLeft: "8%",
    color: "grey",
    fontSize: 22,
  },
});

export default OverView;
