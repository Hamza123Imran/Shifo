import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import { WebView } from "react-native-webview";
import Header from "../components/Header";

export default class Unstopped extends Component {
  render() {
    return (
      <View style={{ flex: 1 }}>
        <Header
          mainTitle="Unstopable Domains"
          subTitle=""
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <WebView
          originWhitelist={["*"]}
          source={{ uri: "https://unstoppabledomains.com/" }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({});
