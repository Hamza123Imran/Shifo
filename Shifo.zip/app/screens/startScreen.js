import * as React from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  Image,
  TouchableOpacity,
} from "react-native";

class StartScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.innerContainer}>
          <Text style={styles.mainText}>Welcome to Shifo wallet</Text>
          <Image
            source={require("../../assets/icon.png")}
            style={styles.icon}
          />

          <TouchableOpacity style={styles.FBtn}>
            <Text
              style={styles.FbtnText}
              onPress={() => this.props.navigation.push("Provider")}
            >
              ADVANCE WALLET CREATION
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.AWCBtn}
            onPress={() => this.props.navigation.push("Provider")}
          >
            <Text style={styles.abtnText}>ADVANCE WALLET CREATION</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.restoreBtn}>
          <Text style={styles.rbtnText}>RESTORE A WALLET</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
  mainText: {
    fontSize: 24,
    color: "#222222",
    fontWeight: "bold",
  },
  icon: {
    width: "60%",
    height: (Dimensions.get("window").width / 100) * 60,
    marginTop: 25,
  },
  restoreBtn: {
    backgroundColor: "#3273e2",
    padding: 14,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  innerContainer: {
    flex: 1,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  rbtnText: {
    color: "white",
    fontSize: 16,
  },
  AWCBtn: {
    padding: 14,
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
  },
  abtnText: {
    color: "#3273e2",
    fontSize: 16,
  },
  FBtn: {
    padding: 11,
    width: "90%",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#3273e2",
    marginTop: (Dimensions.get("window").height / 100) * 10,
  },
  FbtnText: {
    color: "white",
    fontSize: 14,
  },
});

export default StartScreen;
