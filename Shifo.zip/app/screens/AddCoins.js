import * as React from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import Header from "../../src/components/Header";

class AddCoins extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          mainTitle="Add coins"
          subTitle=" Default Wallet"
          openDrawer={() => this.props.navigation.openDrawer()}
        />

        <View style={styles.section1}>
          <Image
            style={{ width: 35, height: 35, marginLeft: 20 }}
            source={require("../../assets/Bicon.png")}
          />
          <View style={styles.section}>
            <View style={styles.sec1}>
              <Text>Bitcoin</Text>
              <Text>16771.74</Text>
            </View>
            <View style={styles.sec2}>
              <Text style={{ color: "grey" }}>BTC</Text>
              <Text>USD</Text>
            </View>
            <View></View>
          </View>
        </View>
        <View style={styles.section1}>
          <Image
            style={{ width: 35, height: 35, marginLeft: 20 }}
            source={require("../../assets/Bicon.png")}
          />
          <View style={styles.section}>
            <View style={styles.sec1}>
              <Text>Bitcoin</Text>
              <Text>16771.74</Text>
            </View>
            <View style={styles.sec2}>
              <Text style={{ color: "grey" }}>BTC</Text>
              <Text>USD</Text>
            </View>
            <View></View>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    flex: 1,
  },
  section1: {
    flexDirection: "row",
    padding: 14,
    paddingLeft: 0,
    borderBottomWidth: 0.2,
  },
  section: {
    flexDirection: "row",
    paddingTop: 10,
  },
  sec1: {
    marginLeft: 20,
    marginRight: 10,
  },
});

export default AddCoins;
