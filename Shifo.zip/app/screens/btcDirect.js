import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import { WebView } from "react-native-webview";
import Header from "../components/Header";

export default class Unstopped extends Component {
  render() {
    return (
      <View style={{ flex: 1 }}>
        <Header
          mainTitle="BTC Direct"
          subTitle="Default Wallet"
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <WebView
          originWhitelist={["*"]}
          source={{ uri: "https://btcdirect.eu/nl-nl" }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({});
