import React, { Component } from "react";
import { View, Text, StyleSheet, Image, ScrollView } from "react-native";
import { TextInput } from "react-native-paper";
import Header from "../components/Header";

export default class Changelly extends Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          mainTitle="Exchange"
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <ScrollView style={styles.innerContainer}>
          <Text>Select the coins you wish to exchange.</Text>
          <Text>The converted will be automatically added to your wallet.</Text>
          <Text style={{ color: "orange" }}>
            Given rate DOES NOT INCLUDE transaction fee
          </Text>
          <View style={styles.section1}>
            <View>
              <Text>Exchange</Text>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: 10,
                }}
              >
                <Image
                  source={require("../../assets/Bicon.png")}
                  style={{ width: 30, height: 30 }}
                />
                <Text style={{ marginLeft: 20 }}>Bitcoin</Text>
              </View>
            </View>
            <View>
              <Text>Receive</Text>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "center",
                  alignItems: "center",
                  marginTop: 10,
                }}
              >
                <Image
                  source={require("../../assets/icons/ethereumclassic.png")}
                  style={{ width: 30, height: 30 }}
                />
                <Text style={{ marginLeft: 20 }}>Ethereum</Text>
              </View>
            </View>
          </View>
          <Text style={{ fontSize: 14, color: "blue", marginTop: 40 }}>
            USE ALL FUNDS
          </Text>
          <Text style={{ marginTop: 19, marginBottom: 10 }}>Amount</Text>
          <View style={styles.section2}>
            <View style={styles.btc}>
              <TextInput
                style={styles.input}
                placeholder="1.00"
                keyboardType="number-pad"
              />
              <Text style={{ alignSelf: "flex-end" }}>BTC</Text>
            </View>
            <View style={styles.eth}>
              <TextInput
                style={styles.input}
                placeholder="33.9073884179"
                keyboardType="number-pad"
              />
              <Text style={{ alignSelf: "flex-end" }}>ETH</Text>
            </View>
          </View>
          <Text style={styles.t}>
            The provided rate is guaranteed for 10 minutes.
          </Text>
          <Text style={styles.t}>Rate:33.9073884179 ETH</Text>
          <Text style={styles.t}>Minimum amount :0.00310995 BTC</Text>
          <Text style={styles.t}>Maximum amount:5.00 BTC</Text>
        </ScrollView>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  section1: {
    flexDirection: "row",
    marginTop: 20,
    justifyContent: "space-between",
  },
  innerContainer: {
    padding: "5%",
    backgroundColor: "white",
    flex: 1,
  },
  section2: {
    flexDirection: "row",
    flex: 1,
    width: "100%",
    height: "10%",
    maxHeight: "19%",
    marginTop: "2%",
    marginBottom: 15,
  },
  btc: {
    width: "49%",
    marginRight: "2%",
  },
  eth: {
    width: "49%",
  },
  t: {
    color: "orange",
    fontSize: 17,
  },
  input: {
    backgroundColor: "white",
  },
});
