import React, { Component } from "react";
import { StyleSheet, View } from "react-native";
import { WebView } from "react-native-webview";
import Header from "../components/Header";

export default class totleSwap extends Component {
  render() {
    return (
      <View style={{ flex: 1 }}>
        <Header
          mainTitle="Totle Swap"
          subTitle=""
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <WebView
          originWhitelist={["*"]}
          source={{ uri: "https://totle.exchange/" }}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({});
