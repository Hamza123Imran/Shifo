import React, { Component } from "react";
import { Text, StyleSheet, View, Button } from "react-native";
import { TouchableOpacity } from "react-native-gesture-handler";
import UsdVsBtc from "../../src/components/UsdVsBtc";
import Header from "../components/Header";
import theme from "../styles/theme";

export default class CryptoSimplex extends Component {
  render() {
    return (
      <View style={{ flex: 1, backgroundColor: "white" }}>
        <Header
          mainTitle="Buy Crypto with Credit Card"
          subTitle="Default Wallet"
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <View style={styles.container}>
          <Text style={styles.simplexText}>Simplex </Text>
          <Text style={styles.smallText}>
            Purchase crypto with your debit/credit card via our partner Simplex.
          </Text>
          <Text style={styles.smallText}>Deposit to</Text>

          <UsdVsBtc />
          <Text style={styles.smallText}>Address</Text>
          <Text>bc1q3m404w641azhyqllajhsajss8723823sd2</Text>

          <View style={styles.btn}>
            <TouchableOpacity>
              <Text style={{ color: "white" }}>
                BUY BITCOIN WITH CREDIT CARD
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: "5%",
  },
  simplexText: {
    fontSize: 24,
    fontWeight: "bold",
  },
  smallText: {
    fontSize: 18,
    marginTop: 20,
  },
  btn: {
    alignSelf: "center",
    justifyContent: "center",
    backgroundColor: theme.mainColor,
    padding: 10,
    bottom: 10,
    position: "absolute",
    width: "100%",
    alignItems: "center",
  },
});
