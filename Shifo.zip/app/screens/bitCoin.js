import * as React from "react";
import { View, Text, StyleSheet } from "react-native";
import UsdVsBtc from "../../src/components/UsdVsBtc";
import FloatingButton from "../../src/components/FloatingButton";
import Header from "../../src/components/Header";
import theme from "../styles/theme";

class BitCoin extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Header
          mainTitle="Bitcoin"
          subTitle=" Default Wallet"
          openDrawer={() => this.props.navigation.openDrawer()}
        />
        <View style={styles.section}>
          <Text style={styles.ttext}>0.00</Text>
          <Text style={styles.tcurrency}>USD</Text>
        </View>

        <Text style={styles.lightText}>No coins received so far</Text>
        <Text style={styles.blueText}>BUY BITCOIN WITH CREDIT CARD</Text>

        <FloatingButton />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    flex: 1,
  },
  section: {
    marginTop: "15%",
    alignSelf: "center",
    marginBottom: "10%",
  },
  ttext: {
    fontSize: 42,
    color: "grey",
  },
  tcurrency: {
    marginLeft: "8%",
    color: "grey",
    fontSize: 22,
  },
  lightText: {
    fontSize: 22,
    color: "lightgray",
    alignSelf: "center",
  },
  blueText: {
    color: "#3273e2",
    alignSelf: "center",
    marginTop: 25,
  },
});

export default BitCoin;
