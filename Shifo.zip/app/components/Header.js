import * as React from "react";
import { Appbar } from "react-native-paper";
import { Ionicons } from "@expo/vector-icons";
import { TouchableOpacity } from "react-native";

const MyComponent = (props) => {
  //   const _goBack = () => console.log('Went back');

  const _handleSearch = () => console.log("Searching");

  const _handleMore = () => console.log("Shown more");

  return (
    <Appbar.Header style={{ backgroundColor: "#3273e2" }}>
      {/* <Appbar.BackAction onPress={_goBack} /> */}
      <TouchableOpacity style={{ marginLeft: "4%" }} onPress={props.openDrawer}>
        <Ionicons name="md-menu" size={32} color="white" />
      </TouchableOpacity>
      <Appbar.Content title={props.mainTitle} subtitle={props.subTitle} />
      <Appbar.Action icon="magnify" onPress={_handleSearch} />
      <Appbar.Action icon="dots-vertical" onPress={_handleMore} />
    </Appbar.Header>
  );
};

export default MyComponent;
