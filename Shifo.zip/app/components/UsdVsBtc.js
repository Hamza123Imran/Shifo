import * as React from "react";
import { View, Text, StyleSheet, Image } from "react-native";

class UsdVsBtc extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <View style={styles.section1}>
          <Image
            style={{ width: 45, height: 45, marginLeft: 20 }}
            source={require("../../assets/Bicon.png")}
          />
          <View style={styles.dot} />
        </View>
        <View style={styles.section2}>
          <Text style={styles.text1}>Bitcoin</Text>
          <Text style={styles.text2}>~15213.26 USD</Text>
        </View>

        <View style={styles.section3}>
          <Text style={styles.text1}>0.00 USD</Text>
          <Text style={{ marginLeft: "7%" }}>0.00 BTC</Text>
        </View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    backgroundColor: "white",
    marginTop: "5%",
  },
  bitcoin: {},
  dot: {
    width: 10,
    height: 10,
    backgroundColor: "green",
    borderRadius: 20 / 2,
    alignSelf: "flex-end",
    marginRight: 10,
    marginTop: -5,
  },
  text1: {
    fontSize: 16,
  },
  text2: {},
  section1: {
    width: "20%",
    marginRight: 10,
  },
  section2: {
    flex: 1,
  },
  section3: {
    flex: 1,
    alignItems: "flex-end",
    marginRight: 20,
  },
});

export default UsdVsBtc;
