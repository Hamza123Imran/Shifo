import React from "react";
import { createDrawerNavigator } from "@react-navigation/drawer";
import { DrawerContent } from "../navigation/DrawerContent";
import OverView from "../screens/OverView";
import TotleSwap from "../screens/totleSwap";
import FIO from "../screens/fio";
import Unstopped from "../screens/unstopped";
import Changelly from "../screens/Changelly";
import BTC from "../screens/btcDirect";
import CryptoSimplex from "../screens/CryptoSimplex";
import BitCoin from "../screens/bitCoin";
import GiftCard from "../screens/GiftCard";
import AddCoins from "../screens/AddCoins";

const Drawer = createDrawerNavigator();

const AuthStack = () => {
  let routeName;

  return (
    <Drawer.Navigator
      initialRouteName={"HomeScreen"}
      //initialRouteName={routeName}
      drawerStyle={{ width: "70%" }}
      //hideStatusBar={true}
      overlayColor={30}
      sceneContainerStyle={{ opacity: 20, shadowOpacity: 70 }}
      drawerContent={(props) => <DrawerContent {...props} />}
    >
      <Drawer.Screen
        name="HomeScreen"
        component={OverView}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="TotleSwap"
        component={TotleSwap}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="FIO"
        component={FIO}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="Unstopped"
        component={Unstopped}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="Changelly"
        component={Changelly}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="BTC"
        component={BTC}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="CryptoSimplex"
        component={CryptoSimplex}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="BitCoin"
        component={BitCoin}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="GiftCard"
        component={GiftCard}
        options={{ header: () => null }}
      />
      <Drawer.Screen
        name="AddCoins"
        component={AddCoins}
        options={{ header: () => null }}
      />
    </Drawer.Navigator>
  );
};

export default AuthStack;
