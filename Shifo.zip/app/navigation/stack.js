import * as React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import StartScreen from "../screens/startScreen";
import Index from "./index";
import AddCoins from "../screens/AddCoins";

const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen
          options={{ header: () => null }}
          name="Provider"
          component={Index}
        />
        <Stack.Screen
          options={{ header: () => null }}
          name="Add Coins"
          component={AddCoins}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
