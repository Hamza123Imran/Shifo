import React, { useState } from "react";
import { StyleSheet, View, Image, TouchableOpacity } from "react-native";
import { Text } from "react-native-paper";
import { DrawerContentScrollView } from "@react-navigation/drawer";

import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from "react-native-responsive-screen";

import Icon from "react-native-vector-icons/FontAwesome5";
import theme from "../styles/theme";

export function DrawerContent(props) {
  return (
    <View style={{ flex: 1 }}>
      <DrawerContentScrollView
        style={{ backgroundColor: theme.mainColor }}
        {...props}
      >
        <View style={styles.drawerContent}>
          <View style={styles.userInfoSection}>
            <Image
              style={styles.tinyLogo}
              source={require("../../assets/icon.png")}
            />
            <Text
              style={{
                fontSize: 25,
                paddingLeft: 10,
                color: theme.whiteColor,
              }}
            >
              Shifo
            </Text>
          </View>

          <View style={{ backgroundColor: "white" }}>
            <Text style={styles.label}>Exchange</Text>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("Changelly")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/changelly.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Changelly</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("Changelly")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/coins.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Coinswitch</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("TotleSwap")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/totleswap.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Totle Swap</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.border} />

            <Text style={styles.label}>Buy</Text>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("CryptoSimplex")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/cryptop.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Crypto (Simplex)</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("BTC")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/cryptobtc.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Crypto (BTC Direct)</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("GiftCard")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/giftcards.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Gift Cards</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.border} />

            <Text style={styles.label}>Domains & Addresses</Text>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("FIO")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/Fio.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>FIO</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("Unstopped")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icons/unstopable.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Unstopable Domains</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.border} />

            <Text style={styles.label}>Assets</Text>
            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("HomeScreen")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/icon.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Overview</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.itemsMainContainen}>
              <TouchableOpacity
                style={{ flexDirection: "row", alignItems: "center" }}
                onPress={() => props.navigation.navigate("BitCoin")}
              >
                <View style={styles.menuView}>
                  <Image
                    source={require("../../assets/Bicon.png")}
                    style={styles.icon}
                  />
                </View>
                <Text style={styles.textMenu}>Bitcoin</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.border} />
          </View>
        </View>
      </DrawerContentScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  drawerContent: {
    flex: 1,
  },
  userInfoSection: {
    flexDirection: "row",
    paddingTop: 55,
    paddingLeft: 25,
    paddingBottom: 55,
    alignItems: "center",
  },
  menuViewS: {
    borderTopColor: theme.mainColor,
    borderTopWidth: 2.5,
    borderColor: "#E1E1E1",
    height: 80,
    width: 80,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 5,
  },
  textMenuS: {
    fontSize: 16,
    fontWeight: "bold",
    paddingLeft: 30,
    fontSize: 23,
    color: theme.mainColor,
    fontWeight: "bold",
  },
  menuView: {
    height: 16,
    width: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  textMenu: {
    fontSize: 16,
    paddingLeft: 30,
    color: theme.borderColor,
    fontWeight: "bold",
  },

  buttonLogout: {
    backgroundColor: theme.mainColor,
    borderRadius: 50,
    //marginBottom: 12.27,
    //marginTop: hp('9%'),
    height: hp("5%"), // 70% of height device screen
    width: wp("30%"), // 80% of width device screen
    alignSelf: "center",
    alignItems: "center",
    justifyContent: "center",
  },
  textLogout: {
    textAlign: "center",
    fontStyle: "normal",
    fontWeight: "normal",
    fontSize: wp("3%"),
    alignItems: "center",
    textAlign: "center",
    display: "flex",
    color: theme.whiteColor,
  },
  caption: {
    fontSize: 14,
    lineHeight: 14,
  },
  row: {
    marginTop: 20,
    flexDirection: "row",
    alignItems: "center",
  },
  section: {
    flexDirection: "row",
    alignItems: "center",
    marginRight: 15,
  },

  drawerSection: {
    marginTop: 15,
  },
  bottomDrawerSection: {
    paddingTop: 200,
  },
  tinyLogo: {
    width: 40,
    height: 40,
  },
  itemsMainContainen: {
    flexDirection: "column",
    paddingLeft: 25,
    paddingTop: 25,
  },
  itemsContainer: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 10,
  },
  label: {
    padding: 20,
    fontSize: 15,
    color: "gray",
    fontWeight: "bold",
  },
  border: {
    borderBottomColor: "lightgray",
    borderBottomWidth: 1,
    marginTop: 20,
  },
  icon: {
    width: 27,
    height: 27,
  },
});
