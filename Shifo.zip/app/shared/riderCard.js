import React from 'react';
import {StyleSheet, Text, TouchableOpacity, Image, View} from 'react-native';
import Theme from '../styles/theme';
import {Card} from 'react-native-paper';

export default function RiderCard(props) {
  return (
    <Card style={styles.container}>
      <View style={styles.innerContainer}>
        <TouchableOpacity
          style={styles.avatarContainer}
          onPress={props.onProfilePress}>
          <Image style={styles.avatar} source={props.imageSource} />
        </TouchableOpacity>

        <Text style={styles.lable}>{props.time}</Text>
        <Text style={styles.lable}>{props.name}</Text>

        <TouchableOpacity
          style={styles.orderButton}
          onPress={props.onOrderPress}>
          <Text style={{color: 'white'}}>ORDER</Text>
        </TouchableOpacity>
      </View>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: (Theme.width / 100) * 28,
    marginBottom: 10,
    elevation: 5,
  },
  lable: {
    color: Theme.mainColor,
    fontSize: 17,
  },
  innerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  avatarContainer: {
    width: 60,
    height: 60,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  orderButton: {
    backgroundColor: '#4a4b56',
    padding: 5,
    margin: 10,
    width: '80%',
    borderRadius: 2.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
