import React from 'react';
import {StyleSheet, Text, TouchableOpacity} from 'react-native';
import Theme from '../styles/theme';
import {Card} from 'react-native-paper';
import Icon from 'react-native-vector-icons/Ionicons';

export default function navigatorButton(props) {
  return (
    <Card style={styles.container}>
      <TouchableOpacity style={styles.innerContainer} onPress={props.onPress}>
        <Icon name={props.iconName} size={36} color={Theme.mainColor} />
        <Text style={styles.lable}>{props.lable}</Text>
      </TouchableOpacity>
    </Card>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: (Theme.width / 100) * 16,
    elevation: 5,
  },
  lable: {
    color: Theme.mainColor,
    fontSize: 17,
  },
  innerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
});
