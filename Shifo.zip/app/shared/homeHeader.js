import React from 'react';
import {StyleSheet, Text, Image, View, TouchableOpacity} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import theme from '../styles/theme';
import Icon from 'react-native-vector-icons/FontAwesome5';

const HomeHeader = () => {
  return (
    <View style={styles.container}>
      <View style={styles.infoSection}>
        <Image style={{}} source={require('../assets/images/logo.png')} />
        <Text style={styles.textHeader}>FOODGHAR</Text>
      </View>
      <View style={{flexDirection: 'row', alignItems: 'center'}}>
        <TouchableOpacity style={styles.buttonPause}>
          <Text style={styles.textPause}>Pause Orders</Text>
        </TouchableOpacity>
        <View style={styles.viewIcon}>
          <Icon name="sliders-h" size={hp('1.5%')} color={theme.borderColor} />
        </View>
      </View>
    </View>
  );
};

export default HomeHeader;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 50,
    paddingLeft: 35,
    paddingRight: 35,
  },
  infoSection: {
    flexDirection: 'row',
  },
  textHeader: {
    fontSize: 35,
    paddingLeft: 10,
    color: theme.mainColor,
    bottom: 5,
  },
  buttonPause: {
    backgroundColor: theme.mainColor,
    borderRadius: 3,
    height: hp('3%'),
    width: wp('20%'),
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
  },
  textPause: {
    textAlign: 'center',
    fontFamily: theme.fontFamily,
    fontStyle: 'normal',
    fontWeight: 'normal',
    fontSize: wp('2%'),
    alignItems: 'center',
    textAlign: 'center',
    display: 'flex',
    color: theme.whiteColor,
  },
  viewIcon: {
    height: (theme.width / 100) * 5,
    width: (theme.width / 100) * 5,
    backgroundColor: '#DBDBDB',
    borderRadius: 200,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
